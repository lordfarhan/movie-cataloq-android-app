package me.farhan.moviecataloq.ui.detail

import androidx.lifecycle.ViewModel
import me.farhan.moviecataloq.util.DataDummy

/**
 * @author farhan
 * created at at 15:07 on 23/10/2020.
 */
class TvShowDetailViewModel : ViewModel() {
    var tvShowId: Int = 0
    fun getTvShow() = DataDummy.getTvShowById(tvShowId)
}