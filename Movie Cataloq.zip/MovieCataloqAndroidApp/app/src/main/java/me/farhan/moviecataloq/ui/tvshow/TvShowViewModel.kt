package me.farhan.moviecataloq.ui.tvshow

import androidx.lifecycle.ViewModel
import me.farhan.moviecataloq.data.TvShow
import me.farhan.moviecataloq.util.DataDummy

/**
 * @author farhan
 * created at at 13:40 on 27/10/2020.
 */
class TvShowViewModel : ViewModel() {
    fun getTvShows(): List<TvShow> = DataDummy.getTvShows()
}