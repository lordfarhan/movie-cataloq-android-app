package me.farhan.moviecataloq.ui.movie

import androidx.lifecycle.ViewModel
import me.farhan.moviecataloq.data.Movie
import me.farhan.moviecataloq.util.DataDummy

/**
 * @author farhan
 * created at at 13:52 on 23/10/2020.
 */
class MovieViewModel : ViewModel() {
    fun getMovies(): List<Movie> = DataDummy.getMovies()
}