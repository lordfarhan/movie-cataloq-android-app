package me.farhan.moviecataloq.ui.detail

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_detail.*
import me.farhan.moviecataloq.R

/**
 * @author farhan
 * created at at 9:13 on 23/10/2020.
 */
class DetailActivity : AppCompatActivity() {

    companion object {
        const val MOVIE_ID = "movie_id"
        const val TV_SHOW_ID = "tv_show_id"
    }

    private lateinit var movieViewModel: MovieDetailViewModel
    private lateinit var tvShowViewModel: TvShowDetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        setSupportActionBar(toolbar_detail)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        movieViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[MovieDetailViewModel::class.java]
        tvShowViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[TvShowDetailViewModel::class.java]

        when {
            intent.hasExtra(MOVIE_ID) -> {
                movieViewModel.movieId = intent.getIntExtra(MOVIE_ID, 0)
                supportActionBar?.setTitle(R.string.movie)
                subscribeMovieDetail()
            }
            intent.hasExtra(TV_SHOW_ID) -> {
                tvShowViewModel.tvShowId = intent.getIntExtra(TV_SHOW_ID, 0)
                supportActionBar?.setTitle(R.string.tv_show)
                subscribeTvShowDetail()
            }
            else -> {
                finish()
            }
        }
    }

    private fun subscribeMovieDetail() {
        val movie = movieViewModel.getMovie()!!
        Glide.with(this).load(movie.cover).into(imageView_coverDetail)
        textView_titleDetail.text = movie.title
        textView_ratingDetail.text =
            String.format("%d%% (%d)", movie.rating.toInt(), movie.ratingAmount)
        textView_directorDetail.text = movie.director
        textView_genreDetail.text = movie.genres
        textView_overviewDetail.text = movie.overview
    }

    private fun subscribeTvShowDetail() {
        val tvShow = tvShowViewModel.getTvShow()!!
        Glide.with(this).load(tvShow.cover).into(imageView_coverDetail)
        textView_titleDetail.text = tvShow.title
        textView_ratingDetail.text =
            String.format("%d%% (%d)", tvShow.rating.toInt(), tvShow.ratingAmount)
        textView_directorDetail.text = tvShow.director
        textView_genreDetail.text = tvShow.genres
        textView_overviewDetail.text = tvShow.overview
    }
}