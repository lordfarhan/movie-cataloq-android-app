package me.farhan.moviecataloq.data

/**
 * @author farhan
 * created at at 13:19 on 27/10/2020.
 */
data class TvShow(
    val id: Int,
    val title: String,
    val cover: String,
    val year: Int,
    val genres: String,
    val rating: Double,
    val ratingAmount: Int,
    val director: String,
    val overview: String,
) {
}