package me.farhan.moviecataloq.util

import me.farhan.moviecataloq.data.Movie
import me.farhan.moviecataloq.data.TvShow

/**
 * @author farhan
 * created at at 10:34 on 23/10/2020.
 */
class DataDummy {
    companion object {
        fun getMovies(): List<Movie> {
            val movies: ArrayList<Movie> = ArrayList()
            movies.add(
                Movie(
                    1,
                    "Peninsula",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/sy6DvAu72kjoseZEjocnm2ZZ09i.jpg",
                    2020,
                    "Action, Horror, Thriller",
                    71.0,
                    641,
                    "Yeon Sang-ho",
                    "A soldier and his team battle hordes of post-apocalyptic zombies in the wastelands of the Korean Peninsula.",
                )
            )
            movies.add(
                Movie(
                    2,
                    "We Bare Bears: The Movie",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/kPzcvxBwt7kEISB9O4jJEuBn72t.jpg",
                    2020,
                    "Family, Animation, Adventure, Comedy, Mystery",
                    77.0,
                    452,
                    "Daniel Chong",
                    "When Grizz, Panda, and Ice Bear's love of food trucks and viral videos went out of hand, it catches the attention of Agent Trout from the National Wildlife Control, who pledges to restore the “natural order” by separating them forever. Chased away from their home, the Bears embark on an epic road trip as they seek refuge in Canada, with their journey being filled with new friends, perilous obstacles, and huge parties. The risky journey also forces the Bears to face how they first met and became brothers, in order to keep their family bond from splitting apart."
                )
            )
            movies.add(
                Movie(
                    3,
                    "Artemis Fowl",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/tI8ocADh22GtQFV28vGHaBZVb0U.jpg",
                    2020,
                    "Adventure, Fantasy, Science Fiction, Family, Action",
                    58.0,
                    886,
                    "Kenneth Branagh",
                    "Artemis Fowl is a 12-year-old genius and descendant of a long line of criminal masterminds. He soon finds himself in an epic battle against a race of powerful underground fairies who may be behind his father's disappearance.",
                )
            )
            movies.add(
                Movie(
                    4,
                    "My Hero Academia: Heroes Rising",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/zGVbrulkupqpbwgiNedkJPyQum4.jpg",
                    2019,
                    "Animation, Action",
                    86.0,
                    440,
                    "Kenji Nagasaki",
                    "Class 1-A visits Nabu Island where they finally get to do some real hero work. The place is so peaceful that it's more like a vacation … until they're attacked by a villain with an unfathomable Quirk! His power is eerily familiar, and it looks like Shigaraki had a hand in the plan. But with All Might retired and citizens' lives on the line, there's no time for questions. Deku and his friends are the next generation of heroes, and they're the island's only hope.",
                )
            )
            movies.add(
                Movie(
                    5,
                    "Phineas and Ferb The Movie: Candace Against the Universe",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/n6hptKS7Y0ZjkYwbqKOK3jz9XAC.jpg",
                    2020,
                    "Animation, Science Fiction, Comedy, Music, Family, TV Movie",
                    72.0,
                    121,
                    "Bob Bowen",
                    "Phineas and Ferb travel across the galaxy to rescue their older sister Candace, who has been abducted by aliens and taken to a utopia in a far-off planet, free of her pesky little brothers.",
                )
            )
            movies.add(
                Movie(
                    6,
                    "Scoob!",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/jHo2M1OiH9Re33jYtUQdfzPeUkx.jpg",
                    2020,
                    "Family, Animation, Comedy, Adventure",
                    74.0,
                    789,
                    "Tony Cervone",
                    "In Scooby-Doo’s greatest adventure yet, see the never-before told story of how lifelong friends Scooby and Shaggy first met and how they joined forces with young detectives Fred, Velma, and Daphne to form the famous Mystery Inc. Now, with hundreds of cases solved, Scooby and the gang face their biggest, toughest mystery ever: an evil plot to unleash the ghost dog Cerberus upon the world. As they race to stop this global “dogpocalypse,” the gang discovers that Scooby has a secret legacy and an epic destiny greater than anyone ever imagined.",
                )
            )
            movies.add(
                Movie(
                    7,
                    "Mortal Kombat Legends: Scorpion's Revenge",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/4VlXER3FImHeFuUjBShFamhIp9M.jpg",
                    2020,
                    "Fantasy, Action, Adventure, Animation",
                    84.0,
                    635,
                    "Ethan Spaulding",
                    "After the vicious slaughter of his family by stone-cold mercenary Sub-Zero, Hanzo Hasashi is exiled to the torturous Netherrealm. There, in exchange for his servitude to the sinister Quan Chi, he’s given a chance to avenge his family – and is resurrected as Scorpion, a lost soul bent on revenge. Back on Earthrealm, Lord Raiden gathers a team of elite warriors – Shaolin monk Liu Kang, Special Forces officer Sonya Blade and action star Johnny Cage – an unlikely band of heroes with one chance to save humanity. To do this, they must defeat Shang Tsung’s horde of Outworld gladiators and reign over the Mortal Kombat tournament."
                )
            )
            movies.add(
                Movie(
                    8,
                    "Sonic the Hedgehog",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/aQvJ5WPzZgYVDrxLX4R6cLJCEaQ.jpg",
                    2020,
                    "Action, Science Fiction, Comedy, Family",
                    75.0,
                    5928,
                    "Jeff Fowler",
                    "Based on the global blockbuster videogame franchise from Sega, Sonic the Hedgehog tells the story of the world’s speediest hedgehog as he embraces his new home on Earth. In this live-action adventure comedy, Sonic and his new best friend team up to defend the planet from the evil genius Dr. Robotnik and his plans for world domination.",
                )
            )
            movies.add(
                Movie(
                    9,
                    "Greyhound",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/kjMbDciooTbJPofVXgAoFjfX8Of.jpg",
                    2020,
                    "War, Action, Drama",
                    75.0,
                    1270,
                    "Aaron Schneider",
                    "A first-time captain leads a convoy of allied ships carrying thousands of soldiers across the treacherous waters of the “Black Pit” to the front lines of WW2. With no air cover protection for 5 days, the captain and his convoy must battle the surrounding enemy Nazi U-boats in order to give the allies a chance to win the war."
                )
            )
            movies.add(
                Movie(
                    10,
                    "Frozen II",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/pjeMs3yqRmFL3giJy4PMXWZTTPa.jpg",
                    2019,
                    "Animation, Family, Adventure, Comedy, Fantasy",
                    73.0,
                    6274,
                    "Jennifer Lee",
                    "Elsa, Anna, Kristoff and Olaf head far into the forest to learn the truth about an ancient mystery of their kingdom."
                )
            )
            return movies
        }

        fun getMovieById(id: Int): Movie? {
            var movie: Movie? = null
            getMovies().forEach {
                if (it.id == id) movie = it
            }
            return movie
        }

        fun getTvShows(): List<TvShow> {
            val tvShows: ArrayList<TvShow> = ArrayList()
            tvShows.add(
                TvShow(
                    1,
                    "Peninsula",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/sy6DvAu72kjoseZEjocnm2ZZ09i.jpg",
                    2020,
                    "Action, Horror, Thriller",
                    71.0,
                    641,
                    "Yeon Sang-ho",
                    "A soldier and his team battle hordes of post-apocalyptic zombies in the wastelands of the Korean Peninsula.",
                )
            )
            tvShows.add(
                TvShow(
                    2,
                    "We Bare Bears: The Movie",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/kPzcvxBwt7kEISB9O4jJEuBn72t.jpg",
                    2020,
                    "Family, Animation, Adventure, Comedy, Mystery",
                    77.0,
                    452,
                    "Daniel Chong",
                    "When Grizz, Panda, and Ice Bear's love of food trucks and viral videos went out of hand, it catches the attention of Agent Trout from the National Wildlife Control, who pledges to restore the “natural order” by separating them forever. Chased away from their home, the Bears embark on an epic road trip as they seek refuge in Canada, with their journey being filled with new friends, perilous obstacles, and huge parties. The risky journey also forces the Bears to face how they first met and became brothers, in order to keep their family bond from splitting apart."
                )
            )
            tvShows.add(
                TvShow(
                    3,
                    "Artemis Fowl",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/tI8ocADh22GtQFV28vGHaBZVb0U.jpg",
                    2020,
                    "Adventure, Fantasy, Science Fiction, Family, Action",
                    58.0,
                    886,
                    "Kenneth Branagh",
                    "Artemis Fowl is a 12-year-old genius and descendant of a long line of criminal masterminds. He soon finds himself in an epic battle against a race of powerful underground fairies who may be behind his father's disappearance.",
                )
            )
            tvShows.add(
                TvShow(
                    4,
                    "My Hero Academia: Heroes Rising",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/zGVbrulkupqpbwgiNedkJPyQum4.jpg",
                    2019,
                    "Animation, Action",
                    86.0,
                    440,
                    "Kenji Nagasaki",
                    "Class 1-A visits Nabu Island where they finally get to do some real hero work. The place is so peaceful that it's more like a vacation … until they're attacked by a villain with an unfathomable Quirk! His power is eerily familiar, and it looks like Shigaraki had a hand in the plan. But with All Might retired and citizens' lives on the line, there's no time for questions. Deku and his friends are the next generation of heroes, and they're the island's only hope.",
                )
            )
            tvShows.add(
                TvShow(
                    5,
                    "Phineas and Ferb The Movie: Candace Against the Universe",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/n6hptKS7Y0ZjkYwbqKOK3jz9XAC.jpg",
                    2020,
                    "Animation, Science Fiction, Comedy, Music, Family, TV Movie",
                    72.0,
                    121,
                    "Bob Bowen",
                    "Phineas and Ferb travel across the galaxy to rescue their older sister Candace, who has been abducted by aliens and taken to a utopia in a far-off planet, free of her pesky little brothers.",
                )
            )
            tvShows.add(
                TvShow(
                    6,
                    "Scoob!",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/jHo2M1OiH9Re33jYtUQdfzPeUkx.jpg",
                    2020,
                    "Family, Animation, Comedy, Adventure",
                    74.0,
                    789,
                    "Tony Cervone",
                    "In Scooby-Doo’s greatest adventure yet, see the never-before told story of how lifelong friends Scooby and Shaggy first met and how they joined forces with young detectives Fred, Velma, and Daphne to form the famous Mystery Inc. Now, with hundreds of cases solved, Scooby and the gang face their biggest, toughest mystery ever: an evil plot to unleash the ghost dog Cerberus upon the world. As they race to stop this global “dogpocalypse,” the gang discovers that Scooby has a secret legacy and an epic destiny greater than anyone ever imagined.",
                )
            )
            tvShows.add(
                TvShow(
                    7,
                    "Mortal Kombat Legends: Scorpion's Revenge",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/4VlXER3FImHeFuUjBShFamhIp9M.jpg",
                    2020,
                    "Fantasy, Action, Adventure, Animation",
                    84.0,
                    635,
                    "Ethan Spaulding",
                    "After the vicious slaughter of his family by stone-cold mercenary Sub-Zero, Hanzo Hasashi is exiled to the torturous Netherrealm. There, in exchange for his servitude to the sinister Quan Chi, he’s given a chance to avenge his family – and is resurrected as Scorpion, a lost soul bent on revenge. Back on Earthrealm, Lord Raiden gathers a team of elite warriors – Shaolin monk Liu Kang, Special Forces officer Sonya Blade and action star Johnny Cage – an unlikely band of heroes with one chance to save humanity. To do this, they must defeat Shang Tsung’s horde of Outworld gladiators and reign over the Mortal Kombat tournament."
                )
            )
            tvShows.add(
                TvShow(
                    8,
                    "Sonic the Hedgehog",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/aQvJ5WPzZgYVDrxLX4R6cLJCEaQ.jpg",
                    2020,
                    "Action, Science Fiction, Comedy, Family",
                    75.0,
                    5928,
                    "Jeff Fowler",
                    "Based on the global blockbuster videogame franchise from Sega, Sonic the Hedgehog tells the story of the world’s speediest hedgehog as he embraces his new home on Earth. In this live-action adventure comedy, Sonic and his new best friend team up to defend the planet from the evil genius Dr. Robotnik and his plans for world domination.",
                )
            )
            tvShows.add(
                TvShow(
                    9,
                    "Greyhound",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/kjMbDciooTbJPofVXgAoFjfX8Of.jpg",
                    2020,
                    "War, Action, Drama",
                    75.0,
                    1270,
                    "Aaron Schneider",
                    "A first-time captain leads a convoy of allied ships carrying thousands of soldiers across the treacherous waters of the “Black Pit” to the front lines of WW2. With no air cover protection for 5 days, the captain and his convoy must battle the surrounding enemy Nazi U-boats in order to give the allies a chance to win the war."
                )
            )
            tvShows.add(
                TvShow(
                    10,
                    "Frozen II",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/pjeMs3yqRmFL3giJy4PMXWZTTPa.jpg",
                    2019,
                    "Animation, Family, Adventure, Comedy, Fantasy",
                    73.0,
                    6274,
                    "Jennifer Lee",
                    "Elsa, Anna, Kristoff and Olaf head far into the forest to learn the truth about an ancient mystery of their kingdom."
                )
            )
            return tvShows.reversed()
        }

        fun getTvShowById(id: Int): TvShow? {
            var tvShow: TvShow? = null
            getTvShows().forEach {
                if (it.id == id) tvShow = it
            }
            return tvShow
        }
    }
}