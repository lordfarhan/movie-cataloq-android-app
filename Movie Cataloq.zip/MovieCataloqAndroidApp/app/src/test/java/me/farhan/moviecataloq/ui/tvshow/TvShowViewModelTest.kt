package me.farhan.moviecataloq.ui.tvshow

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

/**
 * @author farhan
 * created at at 11:16 on 02/11/2020.
 */
class TvShowViewModelTest {

    private lateinit var viewModel: TvShowViewModel

    @Before
    fun setUp() {
        viewModel = TvShowViewModel()
    }

    @Test
    fun getTvShows() {
        val entities = viewModel.getTvShows()
        assertNotNull(entities)
        assertEquals(10, entities.size)
    }
}