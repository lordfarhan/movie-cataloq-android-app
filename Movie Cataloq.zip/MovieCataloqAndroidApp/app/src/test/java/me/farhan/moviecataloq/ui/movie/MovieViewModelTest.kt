package me.farhan.moviecataloq.ui.movie

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

/**
 * @author farhan
 * created at at 11:08 on 02/11/2020.
 */
class MovieViewModelTest {

    private lateinit var viewModel: MovieViewModel

    @Before
    fun setUp() {
        viewModel = MovieViewModel()
    }

    @Test
    fun getMovies() {
        val entities = viewModel.getMovies()
        assertNotNull(entities)
        assertEquals(10, entities.size)
    }
}