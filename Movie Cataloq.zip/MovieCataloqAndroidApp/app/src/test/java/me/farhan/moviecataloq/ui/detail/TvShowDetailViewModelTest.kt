package me.farhan.moviecataloq.ui.detail

import me.farhan.moviecataloq.util.DataDummy
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/**
 * @author farhan
 * created at at 11:34 on 02/11/2020.
 */
class TvShowDetailViewModelTest {

    private lateinit var viewModel: TvShowDetailViewModel
    private val dummyTvShow = DataDummy.getTvShows()[0]
    private val tvShowId = dummyTvShow.id

    @Before
    fun setUp() {
        viewModel = TvShowDetailViewModel()
        viewModel.tvShowId = tvShowId
    }

    @Test
    fun getTvShowId() {
        val id = viewModel.tvShowId
        assertNotEquals(0, id)
        assertEquals(tvShowId, id)
    }

    @Test
    fun getTvShow() {
        val entity = viewModel.getTvShow()
        assertNotNull(entity)
        assertEquals(dummyTvShow, entity)
    }
}