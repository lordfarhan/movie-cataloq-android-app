package me.farhan.moviecataloq.ui.detail

import me.farhan.moviecataloq.util.DataDummy
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/**
 * @author farhan
 * created at at 11:26 on 02/11/2020.
 */
class MovieDetailViewModelTest {

    private lateinit var viewModel: MovieDetailViewModel
    private val dummyMovie = DataDummy.getMovies()[0]
    private val movieId = dummyMovie.id

    @Before
    fun setUp() {
        viewModel = MovieDetailViewModel()
        viewModel.movieId = movieId
    }

    @Test
    fun getMovieId() {
        val id = viewModel.movieId
        assertNotEquals(0, id)
        assertEquals(movieId, id)
    }

    @Test
    fun getMovie() {
        val entity = viewModel.getMovie()
        assertNotNull(entity)
        assertEquals(dummyMovie, entity)
    }
}